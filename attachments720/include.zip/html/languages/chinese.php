<?php
// 中文语言包
$lang = array(
    'welcome' => '欢迎',
    'student_grade_system' => '学生成绩查询系统',
    'grade_query' => '成绩查询',
    'subject' => '科目',
    'score' => '成绩',
    'semester' => '学期',
    'logout' => '退出登录',
    'no_grades' => '暂无成绩记录',
    'my_grades' => '我的成绩'
);
?>
