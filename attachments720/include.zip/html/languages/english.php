<?php
// English language pack
$lang = array(
    'welcome' => 'Welcome',
    'student_grade_system' => 'Student Grade Query System',
    'grade_query' => 'Grade Query',
    'subject' => 'Subject',
    'score' => 'Score',
    'semester' => 'Semester',
    'logout' => 'Logout',
    'no_grades' => 'No grade records',
    'my_grades' => 'My Grades'
);
?>
