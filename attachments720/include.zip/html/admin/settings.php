<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

checkLogin('admin');

// 获取当前设置
function getSetting($key) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $result = $stmt->fetch();
    return $result ? $result['setting_value'] : '';
}
// 文件日志
function log_system2($content) {
    // 写入log.txt
    $log_file = 'system.log';
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents($log_file, "[$timestamp] $content\n", FILE_APPEND);
    

}

if (isset($_FILES['site_icon'])) {
    log_system2("Icon upload attempt in111itiated");
}
// 设置处理
// if ($_POST) {
//     log_system2("Settings updated by admin: " . $_SESSION['username']);
if (isset($_POST['update_settings'])) {
    $site_title = $_POST['site_title'];
    log_system2("Site title updated to: " . $site_title);
    // 更新设置
    $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = ?");
    $stmt->execute([$site_title, 'site_title']);
    
    $success_message = "设置已更新";
}

    // 处理图标上传
    // if (isset($_POST['upload_icon'])) {
    //     log_system2("Icon upload attempt initiated");

// 处理图标上传
if (isset($_FILES['site_icon']) && $_FILES['site_icon']['error'] == 0) {
    log_system2("Site icon upload initiated by admin: ");
    $upload_dir = '../uploads/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }
    
    $file_name = $_FILES['site_icon']['name'];
    $file_tmp = $_FILES['site_icon']['tmp_name'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    // 检查文件后缀 - 扩展支持的文件类型
    if (!in_array($file_ext, ['jpg', 'jpeg', 'png', 'gif', 'ico'])) {
        $icon_error = "只允许上传 JPG、PNG、GIF 或 ICO 格式的图片文件";
        log_system2($icon_error);
    } else {
        $upload_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($file_tmp, $upload_path)) {
            $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = ?");
            $stmt->execute([$file_name, 'site_icon']);
            $icon_success = "图标上传成功";
            log_system2("Site icon uploaded successfully: " . $file_name);
        } else {
            $icon_error = "图标上传失败，请检查文件权限";
            log_system2($icon_error);
        }
    }
}

// }

// 处理语言设置
if (isset($_POST['set_language'])) {
    $langFile = $_POST['langFile'];
    
    // // 检查是否包含.php
    // if (strpos($langFile, '.php') === false) {
    //     $lang_error = "不允许非php文件的语言文件";
    // } else {
        // 检查文件是否存在
    $lang_file_path = '../languages/' . $langFile;
    if (file_exists($lang_file_path)) {
        $stmt = $pdo->prepare("UPDATE system_settings SET setting_value = ? WHERE setting_key = ?");
        $stmt->execute([$langFile, 'site_language']);
        $lang_success = "语言设置已更新";
    } else {
        $lang_error = "不存在该语言包";
    }
    }
// }
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>系统设置</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .main-content {
            max-width: 800px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .content-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .success {
            background: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .back-btn {
            background: #6c757d;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
        }

        .file-info {
            margin-top: 10px;
            padding: 10px;
            background: #f8f9fa;
            border-radius: 5px;
            font-size: 14px;
            color: #666;
        }

        .upload-preview {
            margin-top: 10px;
            max-width: 100px;
            max-height: 100px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .loading {
            display: none;
            color: #007bff;
            font-style: italic;
        }
    </style>
    <script>
        function validateFileUpload() {
            const fileInput = document.getElementById('site_icon');
            const file = fileInput.files[0];
            
            if (!file) {
                alert('请选择要上传的文件');
                return false;
            }
            
            // 检查文件大小 (2MB = 2 * 1024 * 1024 bytes)
            if (file.size > 2 * 1024 * 1024) {
                alert('文件大小不能超过2MB');
                return false;
            }
            
            // 检查文件类型
            const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/x-icon'];
            if (!allowedTypes.includes(file.type)) {
                alert('只允许上传 JPG、PNG、GIF 或 ICO 格式的图片文件');
                return false;
            }
            
            // 显示加载状态
            document.querySelector('.loading').style.display = 'inline';
            document.querySelector('button[name="upload_icon"]').disabled = true;
            
            return true;
        }
        
        function previewImage() {
            const fileInput = document.getElementById('site_icon');
            const file = fileInput.files[0];
            const preview = document.getElementById('image-preview');
            const fileInfo = document.getElementById('file-info');
            
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
                
                fileInfo.innerHTML = `文件名: ${file.name}<br>大小: ${(file.size / 1024).toFixed(2)} KB<br>类型: ${file.type}`;
                fileInfo.style.display = 'block';
            } else {
                preview.style.display = 'none';
                fileInfo.style.display = 'none';
            }
        }
    </script>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>系统设置</h1>
            <a href="dashboard.php" class="back-btn">返回控制台</a>
        </div>
    </div>

    <div class="main-content">
        <!-- 基本设置 -->
        <div class="content-card">
            <h3>基本设置</h3>
            
            <?php if (isset($success_message)): ?>
                <div class="success"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="site_title">网站标题</label>
                    <input type="text" name="site_title" id="site_title" value="<?php echo htmlspecialchars(getSetting('site_title')); ?>" required>
                </div>
                
                <button type="submit" name="update_settings" class="btn">保存设置</button>
            </form>
        </div>

        <!-- 网站图标设置 -->
        <div class="content-card">
            <h3>学生页面网站图标</h3>
            
            <?php if (isset($icon_success)): ?>
                <div class="success"><?php echo $icon_success; ?></div>
            <?php endif; ?>
            
            <?php if (isset($icon_error)): ?>
                <div class="error"><?php echo $icon_error; ?></div>
            <?php endif; ?>
            
            <!-- 显示当前图标 -->
            <?php 
                $current_icon = getSetting('site_icon');
                if ($current_icon && file_exists('../uploads/' . $current_icon)): 
            ?>
                <div class="form-group">
                    <label>当前网站图标</label>
                    <div>
                        <img src="../uploads/<?php echo htmlspecialchars($current_icon); ?>" 
                             alt="当前图标" style="max-width: 64px; max-height: 64px; border: 1px solid #ddd; border-radius: 5px;">
                        <p style="margin-top: 5px; font-size: 14px; color: #666;">
                            文件名: <?php echo htmlspecialchars($current_icon); ?>
                        </p>
                    </div>
                </div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data" onsubmit="return validateFileUpload()">
                <div class="form-group">
                    <label for="site_icon">上传图标文件</label>
                    <input type="file" name="site_icon" id="site_icon" accept=".jpg,.jpeg,.png,.gif,.ico" onchange="previewImage()" required>
                    <small>当前图标: <?php 
                        $current_icon = getSetting('site_icon');
                        echo $current_icon ? htmlspecialchars($current_icon) : '未设置';
                    ?> (支持 JPG、PNG、GIF、ICO 格式，最大2MB)</small>
                    
                    <!-- 文件信息显示 -->
                    <div id="file-info" class="file-info" style="display: none;"></div>
                    
                    <!-- 图片预览 -->
                    <img id="image-preview" class="upload-preview" style="display: none;" alt="预览图片">
                </div>
                
                <button type="submit" name="upload_icon" class="btn">上传图标</button>
                <span class="loading">上传中，请稍候...</span>
            </form>
        </div>

        <!-- 语言设置 -->
        <div class="content-card">
            <h3>学生页面语言设置</h3>
            
            <?php if (isset($lang_success)): ?>
                <div class="success"><?php echo $lang_success; ?></div>
            <?php endif; ?>
            
            <?php if (isset($lang_error)): ?>
                <div class="error"><?php echo $lang_error; ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="langFile">选择语言</label>
                    <select name="langFile" id="langFile" required>
                        <option value="">请选择语言</option>
                        <option value="chinese.php" <?php echo (getSetting('site_language') == 'chinese.php') ? 'selected' : ''; ?>>中文</option>
                        <option value="english.php" <?php echo (getSetting('site_language') == 'english.php') ? 'selected' : ''; ?>>English</option>
                    </select>
                </div>
                
                <button type="submit" name="set_language" class="btn">设置语言</button>
            </form>
            
            <div style="margin-top: 20px;">
                <a href="language_manager.php" class="btn" style="text-decoration: none;">语言包管理</a>
            </div>
        </div>
    </div>
</body>
</html>
