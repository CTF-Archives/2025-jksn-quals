<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

checkLogin('admin');

// 获取现有语言包
$language_dir = '../languages/';
$language_files = array();

if (is_dir($language_dir)) {
    $files = scandir($language_dir);
    foreach ($files as $file) {
        if (pathinfo($file, PATHINFO_EXTENSION) == 'php') {
            $language_files[] = $file;
        }
    }
}

// 处理上传请求（显示安全警告）
if (isset($_POST['upload_language'])) {
    $upload_error = "安全原因，禁止使用此功能";
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>语言包管理</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .main-content {
            max-width: 800px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .content-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .language-list {
            list-style: none;
            padding: 0;
        }

        .language-item {
            background: #f8f9fa;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 5px;
            border-left: 4px solid #667eea;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #333;
            font-weight: bold;
        }

        .form-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        .btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn:hover {
            transform: translateY(-2px);
        }

        .error {
            background: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .back-btn {
            background: #6c757d;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>语言包管理</h1>
            <a href="settings.php" class="back-btn">返回设置</a>
        </div>
    </div>

    <div class="main-content">
        <!-- 现有语言包 -->
        <div class="content-card">
            <h3>现有语言包</h3>
            
            <?php if (empty($language_files)): ?>
                <p>暂无语言包</p>
            <?php else: ?>
                <ul class="language-list">
                    <?php foreach ($language_files as $file): ?>
                        <li class="language-item">
                            <strong><?php echo htmlspecialchars($file); ?></strong>
                            <br>
                            <small>位置: languages/<?php echo htmlspecialchars($file); ?></small>
                        </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>

        <!-- 上传语言包 -->
        <div class="content-card">
            <h3>上传语言包</h3>
            
            <?php if (isset($upload_error)): ?>
                <div class="error"><?php echo $upload_error; ?></div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="language_file">选择语言包文件</label>
                    <input type="file" name="language_file" id="language_file" accept=".php">
                    <small>仅支持PHP格式的语言包文件</small>
                </div>
                
                <button type="submit" name="upload_language" class="btn">上传语言包</button>
            </form>
        </div>
    </div>
</body>
</html>
