<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

checkLogin('admin');

// 统计数据
$stmt = $pdo->query("SELECT COUNT(*) as total_students FROM users WHERE role = 'student'");
$total_students = $stmt->fetch()['total_students'];

$stmt = $pdo->query("SELECT COUNT(*) as total_grades FROM grades");
$total_grades = $stmt->fetch()['total_grades'];

$stmt = $pdo->query("SELECT AVG(score) as avg_score FROM grades");
$avg_score = round($stmt->fetch()['avg_score'], 2);
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>管理员控制台</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .sidebar {
            width: 250px;
            background: white;
            height: calc(100vh - 80px);
            position: fixed;
            left: 0;
            top: 80px;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            overflow-y: auto;
        }

        .sidebar ul {
            list-style: none;
        }

        .sidebar li {
            border-bottom: 1px solid #eee;
        }

        .sidebar a {
            display: block;
            padding: 15px 20px;
            color: #333;
            text-decoration: none;
            transition: background 0.3s;
        }

        .sidebar a:hover, .sidebar a.active {
            background: #f8f9fa;
            color: #667eea;
        }

        .main-content {
            margin-left: 250px;
            padding: 30px;
        }

        .content-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            text-align: center;
        }

        .stat-number {
            font-size: 36px;
            font-weight: bold;
            color: #667eea;
            margin-bottom: 10px;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s;
        }

        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }

        .hidden {
            display: none;
        }

        .debug-form {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 5px;
            border-left: 4px solid #dc3545;
        }

        .debug-form textarea {
            width: 100%;
            height: 100px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-family: monospace;
        }

        .debug-btn {
            background: #dc3545;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            margin-top: 10px;
        }

        .debug-output {
            background: #000;
            color: #0f0;
            padding: 15px;
            border-radius: 5px;
            font-family: monospace;
            white-space: pre-wrap;
            margin-top: 15px;
            min-height: 100px;
        }

        .warning {
            background: #fff3cd;
            color: #856404;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            border-left: 4px solid #ffc107;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <h1>管理员控制台</h1>
            <div class="user-info">
                <span>欢迎，<?php echo $_SESSION['real_name']; ?></span>
                <a href="../logout.php" class="logout-btn">退出登录</a>
            </div>
        </div>
    </div>

    <div class="sidebar">
        <ul>
            <li><a href="#" onclick="showContent('dashboard')" class="active">控制台首页</a></li>
            <li><a href="#" onclick="showContent('students')">学生管理</a></li>
            <li><a href="#" onclick="showContent('grades')">成绩管理</a></li>
            <li><a href="#" onclick="showContent('logs')">系统日志</a></li>
            <li><a href="settings.php">系统设置</a></li>
        </ul>
    </div>

    <div class="main-content">
        <!-- 控制台首页 -->
        <div id="content-dashboard">
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_students; ?></div>
                    <div>学生总数</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $total_grades; ?></div>
                    <div>成绩记录</div>
                </div>
                <div class="stat-card">
                    <div class="stat-number"><?php echo $avg_score; ?></div>
                    <div>平均分</div>
                </div>
            </div>

            <div class="content-card">
                <h3>系统概况</h3>
                <p>欢迎使用学生成绩管理系统，您可以通过左侧菜单进行各项管理操作。</p>
            </div>
        </div>

        <!-- 学生管理 -->
        <div id="content-students" class="hidden">
            <div class="content-card">
                <h3>学生管理</h3>
                <?php
                $stmt = $pdo->query("SELECT * FROM users WHERE role = 'student' ORDER BY student_id");
                $students = $stmt->fetchAll();
                ?>
                <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                    <thead>
                        <tr style="background: #f8f9fa;">
                            <th style="padding: 12px; border: 1px solid #ddd;">学号</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">姓名</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">用户名</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">密码</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">注册时间</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($students as $student): ?>
                        <tr>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo htmlspecialchars($student['student_id']); ?></td>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo htmlspecialchars($student['real_name']); ?></td>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo htmlspecialchars($student['username']); ?></td>
                            <td style="padding: 12px; border: 1px solid #ddd;">1****6</td>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo formatTime($student['created_at']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- 成绩管理 -->
        <div id="content-grades" class="hidden">
            <div class="content-card">
                <h3>成绩管理</h3>
                <?php
                $stmt = $pdo->query("SELECT g.*, u.real_name FROM grades g LEFT JOIN users u ON g.student_id = u.student_id ORDER BY g.semester DESC, g.student_id");
                $grades = $stmt->fetchAll();
                ?>
                <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                    <thead>
                        <tr style="background: #f8f9fa;">
                            <th style="padding: 12px; border: 1px solid #ddd;">学号</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">姓名</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">科目</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">成绩</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">学期</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($grades as $grade): ?>
                        <tr>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo htmlspecialchars($grade['student_id']); ?></td>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo htmlspecialchars($grade['real_name']); ?></td>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo htmlspecialchars($grade['subject']); ?></td>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo $grade['score']; ?></td>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo htmlspecialchars($grade['semester']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- 系统调试 -->
        <div id="content-debug" class="hidden">
            <div class="content-card">
                <h3>PHP代码调试工具</h3>
                
                <div class="warning">
                    <strong>⚠️ 警告：</strong> 此功能仅供系统管理员进行代码调试使用，请谨慎操作！
                </div>

                <div class="debug-form">
                    <h4>PHP代码执行器</h4>
                    <p>用于执行PHP代码片段进行系统调试和故障排查</p>
                    
                    <form method="POST" action="debug_execute.php">
                        <label for="debug_code">输入PHP代码：</label>
                        <textarea name="debug_code" id="debug_code" placeholder="例如：echo phpinfo(); 或 var_dump($_SERVER);"><?php echo isset($_POST['debug_code']) ? htmlspecialchars($_POST['debug_code']) : ''; ?></textarea>
                        <button type="submit" class="debug-btn">执行代码</button>
                    </form>

                    <div style="margin-top: 15px;">
                        <h5>常用调试代码示例：</h5>
                        <div style="font-size: 12px; color: #666; margin-top: 10px;">
                            <div onclick="document.getElementById('debug_code').value=this.getAttribute('data-code')" data-code="echo phpinfo();" style="cursor: pointer; padding: 5px; background: #f8f9fa; margin: 2px 0; border-radius: 3px;">• 查看PHP信息: echo phpinfo();</div>
                            <div onclick="document.getElementById('debug_code').value=this.getAttribute('data-code')" data-code="var_dump($_SERVER);" style="cursor: pointer; padding: 5px; background: #f8f9fa; margin: 2px 0; border-radius: 3px;">• 查看服务器变量: var_dump($_SERVER);</div>
                            <div onclick="document.getElementById('debug_code').value=this.getAttribute('data-code')" data-code="echo 'Current time: ' . date('Y-m-d H:i:s');" style="cursor: pointer; padding: 5px; background: #f8f9fa; margin: 2px 0; border-radius: 3px;">• 获取当前时间: echo 'Current time: ' . date('Y-m-d H:i:s');</div>
                            <div onclick="document.getElementById('debug_code').value=this.getAttribute('data-code')" data-code="echo getcwd();" style="cursor: pointer; padding: 5px; background: #f8f9fa; margin: 2px 0; border-radius: 3px;">• 获取当前目录: echo getcwd();</div>
                        </div>
                    </div>

                    <?php if (isset($_GET['executed'])): ?>
                    <div class="debug-output">
                        代码已执行，详细信息请查看系统日志...
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- 系统日志 -->
        <div id="content-logs" class="hidden">
            <div class="content-card">
                <h3>系统日志</h3>
                <?php
                $stmt = $pdo->query("SELECT * FROM system_logs ORDER BY created_at DESC LIMIT 50");
                $logs = $stmt->fetchAll();
                ?>
                <table style="width: 100%; border-collapse: collapse; margin-top: 20px;">
                    <thead>
                        <tr style="background: #f8f9fa;">
                            <th style="padding: 12px; border: 1px solid #ddd;">时间</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">类型</th>
                            <th style="padding: 12px; border: 1px solid #ddd;">内容</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($logs as $log): ?>
                        <tr>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo formatTime($log['created_at']); ?></td>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo htmlspecialchars($log['log_type']); ?></td>
                            <td style="padding: 12px; border: 1px solid #ddd;"><?php echo htmlspecialchars($log['log_content']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        function showContent(contentId) {
            // 隐藏所有内容
            const contents = document.querySelectorAll('[id^="content-"]');
            contents.forEach(content => content.classList.add('hidden'));
            
            // 显示指定内容
            document.getElementById('content-' + contentId).classList.remove('hidden');
            
            // 更新菜单状态
            const links = document.querySelectorAll('.sidebar a');
            links.forEach(link => link.classList.remove('active'));
            event.target.classList.add('active');
        }
    </script>
</body>
</html>
