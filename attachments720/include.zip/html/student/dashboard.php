<?php
session_start();
require_once '../config/database.php';
require_once '../includes/functions.php';

checkLogin('student');

// 获取网站设置
function getSetting($key) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key = ?");
    $stmt->execute([$key]);
    $result = $stmt->fetch();
    return $result ? $result['setting_value'] : '';
}

// 加载语言包
$site_language = getSetting('site_language');
if ($site_language) {
    $lang_file = '../languages/' . $site_language;
    if (file_exists($lang_file)) {
        include $lang_file;
    }
}

// 如果没有加载语言包，使用默认值
if (!isset($lang)) {
    $lang = array(
        'welcome' => '欢迎',
        'student_grade_system' => '学生成绩查询系统',
        'grade_query' => '成绩查询',
        'subject' => '科目',
        'score' => '成绩',
        'semester' => '学期',
        'logout' => '退出登录',
        'no_grades' => '暂无成绩记录',
        'my_grades' => '我的成绩'
    );
}

$site_title = getSetting('site_title') ?: '学生成绩查询系统';
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($site_title); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Microsoft YaHei', Arial, sans-serif;
            background: #f5f5f5;
        }

        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .header-content {
            max-width: 1200px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
        }

        .header h1 {
            font-size: 24px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .header-icon {
            width: 32px;
            height: 32px;
            border-radius: 4px;
            object-fit: cover;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s;
        }

        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }

        .container {
            max-width: 1000px;
            margin: 30px auto;
            padding: 0 20px;
        }

        .welcome-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            text-align: center;
        }

        .grade-card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.1);
        }

        .grade-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .grade-table th,
        .grade-table td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        .grade-table th {
            background: #f8f9fa;
            font-weight: bold;
        }

        .grade-table tr:hover {
            background: #f8f9fa;
        }

        .no-data {
            text-align: center;
            color: #666;
            padding: 40px;
        }

        .score-high {
            color: #28a745;
            font-weight: bold;
        }

        .score-medium {
            color: #ffc107;
            font-weight: bold;
        }

        .score-low {
            color: #dc3545;
            font-weight: bold;
        }
    </style>
</head>
<body>

    <div class="header">
        <div class="header-content">
            <h1>
                <?php 
                $site_icon = getSetting('site_icon');
                if ($site_icon && file_exists('../uploads/' . $site_icon)): 
                ?>
                    <img src="../uploads/<?php echo htmlspecialchars($site_icon); ?>" alt="网站图标" class="header-icon">
                <?php endif; ?>
                <?php echo htmlspecialchars($lang['student_grade_system']); ?>
            </h1>
            <div class="user-info">
                <span><?php echo $lang['welcome']; ?>，<?php echo $_SESSION['real_name']; ?>（学号：<?php echo $_SESSION['student_id']; ?>）</span>
                <a href="../logout.php" class="logout-btn"><?php echo $lang['logout']; ?></a>
            </div>
        </div>
    </div>

    <div class="container">
        <div class="welcome-card">
            <h2><?php echo $lang['grade_query']; ?></h2>
            <p>您可以在这里查看您的所有课程成绩</p>
        </div>

        <div class="grade-card">
            <h3><?php echo $lang['my_grades']; ?></h3>
            
            <?php
            $stmt = $pdo->prepare("SELECT * FROM grades WHERE student_id = ? ORDER BY semester DESC, subject ASC");
            $stmt->execute([$_SESSION['student_id']]);
            $grades = $stmt->fetchAll();
            ?>

            <?php if (count($grades) > 0): ?>
                <table class="grade-table">
                    <thead>
                        <tr>
                            <th><?php echo $lang['semester']; ?></th>
                            <th><?php echo $lang['subject']; ?></th>
                            <th><?php echo $lang['score']; ?></th>
                            <th>等级</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($grades as $grade): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($grade['semester']); ?></td>
                                <td><?php echo htmlspecialchars($grade['subject']); ?></td>
                                <td>
                                    <?php
                                    $score = $grade['score'];
                                    $class = '';
                                    if ($score >= 90) $class = 'score-high';
                                    elseif ($score >= 80) $class = 'score-medium';
                                    elseif ($score >= 60) $class = 'score-medium';
                                    else $class = 'score-low';
                                    ?>
                                    <span class="<?php echo $class; ?>"><?php echo $score; ?></span>
                                </td>
                                <td>
                                    <?php
                                    if ($score >= 90) echo '<span class="score-high">优秀</span>';
                                    elseif ($score >= 80) echo '<span class="score-medium">良好</span>';
                                    elseif ($score >= 70) echo '<span class="score-medium">中等</span>';
                                    elseif ($score >= 60) echo '<span class="score-medium">及格</span>';
                                    else echo '<span class="score-low">不及格</span>';
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <div class="no-data">
                    <p><?php echo $lang['no_grades']; ?></p>
                </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
