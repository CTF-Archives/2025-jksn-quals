<?php
// 数据库配置
// define('DB_HOST', 'localhost');
// define('DB_NAME', 'grade_system');
// define('DB_USER', 'root');
// define('DB_PASS', 'root');


define('DB_HOST', $_ENV['MYSQL_HOST'] ?: 'db');
define('DB_USER', $_ENV['MYSQL_USER'] ?: 'root');
define('DB_PASS', $_ENV['MYSQL_ROOT_PASSWORD'] ?: 'root');
define('DB_NAME', $_ENV['MYSQL_DATABASE'] ?: 'grade_system');
define('DB_PORT', $_ENV['MYSQL_PORT'] ?: 3306);


try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->exec("set names utf8");
} catch(PDOException $e) {
    die("连接失败（容器环境初始化数据库需要等一段时间，请等待30s后刷新查看）" );
}
?>
