<?php
error_reporting(E_ALL & ~E_WARNING & ~E_NOTICE);
// 检查登录状态
function checkLogin($required_role = null) {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../index.php');
        exit;
    }
    
    if ($required_role && $_SESSION['role'] != $required_role) {
        header('Location: ../index.php');
        exit;
    }
}

// 记录系统日志
function log_system($type, $content) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO system_logs (log_type, log_content) VALUES (?, ?)");
    $stmt->execute([$type, $content]);
}

// 格式化时间
function formatTime($timestamp) {
    return date('Y-m-d H:i:s', strtotime($timestamp));
}
?>
