#include <stdio.h>
#include <string.h>

static char password[20] = "HotPotIsNice";

void check_spell();
void open_gate();

int main(int argc, char const *argv[])
{
    setvbuf(stdin,  NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
    check_spell();
    return 0;
}

void check_spell() 
{
    char spell[10];
    printf("input password:");
    scanf("%s", spell);
    printf(spell); 
    if(strcmp(spell, password)==0) {
        open_gate();
    }
}

void open_gate()
{
    printf("fake{LocalT_TestAB_Is_Great!}\n");
}
