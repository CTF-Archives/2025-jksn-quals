#include <fcntl.h>
#include <iostream> 
#include <cstring>
#include <cstdlib>
#include <unistd.h>
#include <fstream>
#include <vector>
#include <algorithm>
#include <sys/stat.h> 
#include <cerrno>

using namespace std;

class Animal{
private:
	virtual void interative(){
		system("/bin/sh");
	}
protected:
	int age;
	string name;
public:
	virtual void introduce(){
		cout << "My name is " << name << endl;
		cout << "I am " << age << " years old" << endl;
	}
};

class Panda: public Animal{
public:
	Panda(string name, int age){
		this->name = name;
		this->age = age;
        }
        virtual void introduce(){
		Animal::introduce();
                cout << "I am a Panda!" << endl;
        }
};

class RedPanda: public Animal{
public:
        RedPanda(string name, int age){
                this->name = name;
                this->age = age;
        }
        virtual void introduce(){
                Animal::introduce();
                cout << "I am a Red Panda!" << endl;
        }
};

string base64_decode(const string &in) {
    const string base64_chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    string out;
    vector<int> T(256, -1);
    for (int i = 0; i < 64; i++) 
        T[base64_chars[i]] = i; 

    int val = 0, valb = -8;
    for (unsigned char c : in) {
        if (T[c] == -1) 
            continue;
        val = (val << 6) + T[c];
        valb += 6;
        if (valb >= 0) {
            out.push_back(char((val >> valb) & 0xFF));
            valb -= 8;
        }
    }
    return out;
}

int main(int argc, char* argv[]){
	    std::cout.rdbuf()->pubsetbuf(nullptr, 0);
	    std::cin.rdbuf()->pubsetbuf(nullptr, 0);
	    std::cerr.rdbuf()->pubsetbuf(nullptr, 0);
	Animal* huahua = new Panda("HuaHua", 5);
	Animal* firefox = new RedPanda("Firefox", 3);
	
	size_t len;
	char* data;
	unsigned int op;
	while(1){
		cout << "1. introduce\n2. read logs\n3. bye\n4. write logs\n";
		cin >> op;

		switch(op){
			case 1:
				huahua->introduce();
				firefox->introduce();
				break;
			case 2:{
					int fd = open("./logs/log", O_RDONLY);
					if (fd < 0) {
					    cerr << "Error: Cannot open ./logs/log" << endl;
					    break;
					}
					
					struct stat file_stat;
					if (fstat(fd, &file_stat) < 0) {
					    cerr << "Error: Cannot get file size" << endl;
					    close(fd);
					    break;
					}
					len = file_stat.st_size; 
					if (len == 0) {
					    cout << "File is empty" << endl;
					    close(fd);
					    break;
					}

					data = new char[len + 1]; // +1 for null terminator
					read(fd, data, len);
					close(fd);
					cout << "read logs: " << data << endl;
					break;
				}
			case 3:
				delete huahua;
				delete firefox;
				break;
			case 4: {
				cin.ignore(); 
				string b64_data;
				cout << "Enter base64 data: ";
				getline(cin, b64_data); 

				string decoded = base64_decode(b64_data);

				ofstream outfile;
				outfile.open("./logs/log", ios::binary);
				if (outfile.is_open()) {
				    outfile.write(decoded.c_str(), decoded.size());
				    outfile.close();
				    cout << "Data written to ./logs/log" << endl;
				} else {
				    cerr << "Error: Unable to open ./logs/log for writing." << endl;
				     cerr << "errno: " << errno << " - " << strerror(errno) << endl;
				}
				break;
			    }
			default:
				break;
		}
	}

	return 0;	
}
